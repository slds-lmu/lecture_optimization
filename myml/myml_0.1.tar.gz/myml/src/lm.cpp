#include <Rcpp.h>
#include <RcppEigen.h>


// mylm1:
// stupid first try implementation. 
//  - we copy X and add 1-vec for intercept
//  - stupid implementation of normal equations with matrix inversion
// [[Rcpp::export]]
Eigen::VectorXd mylm1(Eigen::MatrixXd X, Eigen::VectorXd y) { 
  const unsigned int n(X.rows()), m(X.cols());
  // we need to copy X here
  Eigen::MatrixXd X0(n, p+1);
  X0.block(0, 1, n, p) = X;
  X0.col(0) = Eigen::VectorXd::Ones(n);

  Eigen::VectorXd theta;
  theta = (X0.transpose() * X0).inverse() * X0.transpose() * y;
  return(theta);
}

// mylm2:
// [[Rcpp::export]]
Eigen::VectorXd mylm2(Eigen::MatrixXd X, Eigen::VectorXd y) { 
  unsigned int n = X.rows();
  unsigned int p = X.cols();
  // we need to copy X here
  Eigen::MatrixXd X0(n, p+1);
  X0.block(0, 1, n, p) = X;
  X0.col(0) = Eigen::VectorXd::Ones(n);

  Eigen::MatrixXd K = X0.transpose() * X0;
  Eigen::VectorXd rhs = X0.transpose() * y;
  Eigen::VectorXd theta = K.ldlt().solve(rhs);
  return(theta);
}

// mylm3:
// [[Rcpp::export]]
Eigen::VectorXd mylm3(Eigen::MatrixXd X, Eigen::VectorXd y) { 
  unsigned int n = X.rows();
  unsigned int p = X.cols();
  // we need to copy X here
  Eigen::MatrixXd X0(n, p+1);
  X0.block(0, 1, n, p) = X;
  X0.col(0) = Eigen::VectorXd::Ones(n);

  Eigen::VectorXd theta = X0.colPivHouseholderQr().solve(y);
  return(theta);
}

// mylm4:
// https://stackoverflow.com/questions/39606224/does-eigen-have-self-transpose-multiply-optimization-like-h-transposeh
// [[Rcpp::export]]
Eigen::VectorXd mylm4(Eigen::MatrixXd &X, Eigen::VectorXd &y) { 
  unsigned int n = X.rows();
  unsigned int p = X.cols();
  // we need to copy X here

  //Eigen::MatrixXd X0(n, p+1);
  //X0.block(0, 1, n, p) = X;
  //X0.col(0) = Eigen::VectorXd::Ones(n);
	
  //Eigen::MatrixXd XtX = Eigen::MatrixXd::Zero(p+1,p+1);
  //XtX.template selfadjointView<Eigen::Lower>().rankUpdate(X0.adjoint());
	//Eigen::VectorXd theta = XtX.selfadjointView<Eigen::Lower>().ldlt().solve(X0.adjoint() * y);
  return(y);
}

