test_that("foo", {
    expect_equal(1, 1)
})

