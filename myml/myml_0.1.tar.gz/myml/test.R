library(devtools)
load_all()
set.seed(1234)
options(width = 160)
x = as.numeric(1:3)

n = 3
X = as.matrix(iris[1:n, 1:2])
y = iris[1:n, 3]


dd = as.data.frame(X)
dd$y = y
mm = lm(y ~ ., data = dd)
beta0 = coef(mm)
print(beta0)

beta1 = mylm4(X, y)
print(beta1)
