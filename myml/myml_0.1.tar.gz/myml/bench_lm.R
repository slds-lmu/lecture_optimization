
# 
# https://stackoverflow.com/questions/76282769/r-performance-of-running-linear-regressions-with-lm-vs-calculating-with-matr
# https://www.r-bloggers.com/2011/07/even-faster-linear-model-fits-with-r-using-rcppeigen/

# dont runt this with devtools!!!
# otherwise timings will be wrong. 
# use "R CMD INSTALL ."

library(microbenchmark)
library(myml)
set.seed(1)
options(warn = 2)
options(width = 200)

gen_data = function(n, p) {
    X = matrix(runif(n * p, -1, 1), n, p)
    y = 1:n + rnorm(n, 0, 3)
    dd = as.data.frame(X)
    dd$y = y
    list(X = X, y = y, df = dd)
}


fit_r1 = function(X, y) {
    X = cbind(1, X)
    beta = solve(t(X) %*% X) %*% t(X) %*% y
    return(beta)
}

fit_r2 = function(X, y) {
    X = cbind(1, X)
    beta = solve(t(X) %*% X, t(X) %*% y)
    return(beta)
}


benchmark = function(n, p, nrep = 10) {
    z = gen_data(n, p)
    b = microbenchmark(times = nrep, unit = "ms",
        lm = lm(y ~ ., data = z$df),
        lmfit = lm.fit(cbind(1, z$X), z$y),
        r1 = fit_r1(z$X, z$y), 
        r2 = fit_r2(z$X, z$y), 
        mylm1 = myml:::mylm1(z$X, z$y),
        mylm2 = myml:::mylm2(z$X, z$y), 
        mylm3 = myml:::mylm3(z$X, z$y) ,
        mylm4 = myml:::mylm4(z$X, z$y) 
    )
    return(b)
}

bench_n = function() {
    n_seq = 2^(1:6) * 10000
    #n_seq = c(100, 400)
    p_fixed = 5
    bs = lapply(n_seq, function(n) {
        summary(benchmark(n, p_fixed))
    })
    cns = bs[[1]]$expr
    b = as.data.frame(do.call(rbind, lapply(bs, function(x) x$mean)))
    colnames(b) = cns
    b = cbind(list(n = n_seq), b)
    print(b)
}

bench_p = function() {
    p_seq = 2^(1:6) * 10
    n_fixed = 1e3
    bs = lapply(p_seq, function(p) {
        summary(benchmark(n_fixed, p))
    })
    cns = bs[[1]]$expr
    b = as.data.frame(do.call(rbind, lapply(bs, function(x) x$mean)))
    colnames(b) = cns
    b = cbind(list(p = p_seq), b)
    print(b)
}

b = benchmark(n=1e2, p=40L, nrep = 20)
print(b)

#bench_p()
